import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "./question3.css";
import { Switch, TextInput } from "@mantine/core";
import { descriptionFormData } from "../../../../../data/data";
const Question3 = ({ HandleSteps }) => {
  const navigate = useNavigate();
  const [clickedText2, setClickedText2] = useState("Select an Application");
  const [clickedText3, setClickedText3] = useState("Select an Application");
  const [inputValue, setInputValue] = useState({
    noOfPumps: "SIMPLEX",
    pumpsDuty: "",
    pannelType: "NONE",
    mounting: "FLOOR",
    pipeMaterial: "default",
    ballValue: "Standard",
    pulsationDampener: "D",
    witness_testing: false,
    splash_sheild: false,
    manifold: false,
    customization:[]
  });
  const [customization, setCustomization] = useState([
    {
      request: "",
      comment: "",
    }
  ]);
  const handleAddCustomization = () => {
    let newOption = { request: "", comment: "" };
    // Check if the last item has empty values for both request and comment
    if (
      customization?.length > 0 &&
      customization[customization.length - 1].request === "" &&
      customization[customization.length - 1].comment === ""
    ) {
      alert("Please fill out the last input");
    } else {
      setCustomization((prevItems) => {
        // Check if prevItems is an array
        return prevItems ? [...prevItems, newOption] : [newOption];
      });
    }
  };
  const handleAccordionClick = (name, text) => {
    setClickedText2(text?.label);
    setInputValue({ ...inputValue, [name]: text?.value });
  };
  const pipeMaterial = descriptionFormData?.pipeMaterial.find(
    (material) => material?.value === inputValue?.pipeMaterial
  );
  const pulsation = descriptionFormData?.pulsationDampener.find(
    (material) => material?.value === inputValue?.pulsationDampener
  );
  const ballType = descriptionFormData?.ballType.find(
    (material) => material?.value === inputValue?.ballValue
  );
  const handleAccordionClick1 = (name, text) => {
    setClickedText3(text);
    setInputValue({ ...inputValue, [name]: text });
  };
  const handleAccordionClick3 = (name, text) => {
    setInputValue({ ...inputValue, [name]: text });
  };
  const panel_type_arr1 = {label:"Inlet/Outlet",value:"inlet_outlet"};
  const panel_type_arr = [{label:"Duty/Standby",value:"duty_standby"}, {label:"Duty/Duty",value:"duty_duty"}];
  const panel_type_arr2 = [{label:"Duty/Duty/Standby",value:"duty_duty_standby"}, {label:"Duty/Duty/Duty",value:"duty_duty_duty"}];
  // UPDATE INPUT STATES
  const duplexInlet = panel_type_arr?.find(
    (material) => material?.value === inputValue?.pumpsDuty
  );
  const triplexInlet = panel_type_arr2?.find(
    (material) => material?.value === inputValue?.pumpsDuty
  );
  console.log(duplexInlet , triplexInlet)
  const handleInputValues = (name, value) => {
    setInputValue({ ...inputValue, [name]: value });
  };
  // ADD DATA IN SESSION STORAGE AND NAVIGATE TO NEXT FORM
  const handleFormSubmit = () => {
    const data = { ...inputValue, customization: customization };
    console.log(data);
    sessionStorage.setItem("step3", JSON.stringify(data));
    HandleSteps(4);
  };
  const handleRemoveCustomization = (index) => {
    const removed = [...customization];
    removed?.splice(index, 1);
    console.log(removed);
    setCustomization(removed);
  };
  useEffect(() => {
    const step3 = JSON.parse(sessionStorage.getItem("step3"));
    if (step3) {
      setInputValue(step3);
      setCustomization(step3?.customization)
      console.log(step3?.customization);
      // setCustomization(step3?.customization);
    }
  }, []);
  return (
    <>
      <div className="q3">
        <p className="sub-title">Skid Options</p>
        <div className="q3-background mb-5">
          <div>
            <div className=" questionheaders">
              <p className="box-heading ">Number of Pumps</p>
              <p>
                Systems are available with 1, 2, or 3 pumps. Duty/duty or
                duty/standby arrangement options are available. Flow capacity
                selection is per pump. Discharge pressure is maximum pressure of
                the entire
              </p>
            </div>
            <div className="d-flex contents align-items-center justify-content-center flex-wrap gap-4">
              <input
                type="radio"
                class="btn-check"
                name="options"
                id="option1"
                autocomplete="off"
                onClick={() => {
                  handleAccordionClick3("pumpsDuty", panel_type_arr1?.value);
                }}
                checked={inputValue?.noOfPumps === "SIMPLEX"}
                onChange={(e) =>
                  handleInputValues("noOfPumps", "SIMPLEX")
                }
              />
              <label class="btn n-o-buttons" for="option1">
                SIMPLEX (1 PUMP)
              </label>
              <input
                type="radio"
                class="btn-check"
                name="options"
                id="option2"
                autocomplete="off"
                checked={inputValue?.noOfPumps === "DUPLEX"}
                onChange={(e) => {
                  handleInputValues("noOfPumps", "DUPLEX");
                 }
                }
              />
              <label class="btn n-o-buttons" for="option2">
                DUPLEX (2 PUMPS)
              </label>
              <input
                type="radio"
                class="btn-check"
                name="options"
                id="option3"
                checked={inputValue?.noOfPumps === "TRIPLEX"}
                autocomplete="off"
                onChange={(e) => {
                  handleInputValues("noOfPumps", "TRIPLEX");
                  
                }}
              />
              <label class="btn n-o-buttons" for="option3">
                TRIPLEX (3 PUMPS)
              </label>
            </div>
          </div>
          <div>
            <div className="questionheaders">
              <p className="box-heading ">Inlet/Outlet Configuration</p>
              <p>Select Pump Inlet/Outlet Configuration</p>
            </div>
            <div className="contents flex-column d-flex align-items-center justify-content-center ">
              <div
                class={
                  inputValue?.noOfPumps == "SIMPLEX"
                    ? "accordion disabel showing position-relative accordion-flush"
                    : "accordion disabel hiding position-relative accordion-flush"
                }
                id="accordionFlushExample1"
              >
                <div className="accordion-item ">
                  <h2 className="accordion-header c-q">
                    <button
                      className="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#flush-collapse"
                      aria-expanded="true"
                      aria-controls="flush-collapse"
                    >
                      Inlet/Outlet
                    </button>
                  </h2>
                </div>
              </div>
              <div
                class={
                  inputValue?.noOfPumps == "DUPLEX"
                    ? "accordion  showing position-relative accordion-flush"
                    : "accordion disabel hiding position-relative accordion-flush"
                }
                id="accordionFlushExample2"
              >
                <div className="accordion-item ">
                  <h2 className="accordion-header c-q">
                    <button
                      className="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#flush-collapse2"
                      aria-expanded="false"
                      aria-controls="flush-collapse2"
                    >
                      {duplexInlet?.label ? duplexInlet?.label : "Select pump duty"}
                    </button>
                  </h2>
                  {panel_type_arr?.map((item, index) => (
                    <div
                      key={index}
                      id="flush-collapse2"
                      data-bs-toggle="collapse"
                      data-bs-target="#flush-collapse2"
                      aria-expanded="false "
                      aria-controls="flush-collapse"
                      className={"accordion-collapse c-pointer collapse "}
                      data-bs-parent="#accordionFlushExample2"
                    >
                      <div
                        className="accordion-body"
                        onClick={() => handleAccordionClick1("pumpsDuty", item?.value)}
                      >
                        {item?.label}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div
                class={
                  inputValue?.noOfPumps == "TRIPLEX"
                    ? "accordion  showing position-relative accordion-flush"
                    : "accordion disabel hiding position-relative accordion-flush"
                }
                id="accordionFlushExample3"
              >
                <div className="accordion-item ">
                  <h2 className="accordion-header c-q">
                    <button
                      className="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#flush-collapse3"
                      aria-expanded="false"
                      aria-controls="flush-collapse3"
                    >
                      {triplexInlet?.label ? triplexInlet?.label : "Select pump duty"}
                    </button>
                  </h2>
                  {panel_type_arr2?.map((item, index) => (
                    <div
                      key={index}
                      id="flush-collapse3"
                      data-bs-toggle="collapse"
                      data-bs-target="#flush-collapse3"
                      aria-expanded="false"
                      aria-controls="flush-collapse3"
                      className={"accordion-collapse c-pointer collapse "}
                      data-bs-parent="#accordionFlushExample3"
                    >
                      <div
                        className="accordion-body"
                        onClick={() => handleAccordionClick1("pumpsDuty", item?.value)}
                      >
                        {item?.label}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="questionheaders">
              <p className="box-heading ">Panel Type</p>
              <p>Select the panel type</p>
            </div>
            <div className="d-flex contents flex-wrap align-items-center justify-content-center gap-4">
              <input
                type="radio"
                class="btn-check"
                name="options2"
                id="option4"
                checked={inputValue?.pannelType === "NONE"}
                autocomplete="off"
                onChange={(e) => handleInputValues("pannelType", "NONE")}
              />
              <label class="btn n-o-buttons" for="option4">
                None
              </label>
              <input
                type="radio"
                class="btn-check"
                name="options2"
                id="option5"
                checked={inputValue?.pannelType === "CONTROLPANEL"}
                autocomplete="off"
                onChange={(e) =>
                  handleInputValues("pannelType", "CONTROLPANEL")
                }
              />
              <label class="btn n-o-buttons" for="option5">
                Control Panel
              </label>
              <input
                type="radio"
                class="btn-check"
                name="options2"
                id="option6"
                checked={inputValue?.pannelType === "JUNCTIONBOX"}
                autocomplete="off"
                onChange={(e) => handleInputValues("pannelType", "JUNCTIONBOX")}
              />
              <label class="btn n-o-buttons" for="option6">
                Junction Box
              </label>
            </div>
          </div>
          <div>
            <div className="questionheaders">
              <p className="box-heading ">Mounting</p>
              <p>Select how the skid will be mounted.</p>
            </div>
            <div className="d-flex flex-column contents align-items-center justify-content-center gap-3">
              <input
                type="radio"
                class="btn-check"
                name="options3"
                id="option7"
                checked={inputValue?.mounting === "FLOOR"}
                autocomplete="off"
                onChange={(e) => handleInputValues("mounting", "FLOOR")}
              />
              <label class="btn n-o-lg-buttons" for="option7">
                Floor
              </label>
              <input
                type="radio"
                class="btn-check"
                name="options3"
                id="option8"
                checked={inputValue?.mounting === "WALL"}
                autocomplete="off"
                onChange={(e) => handleInputValues("mounting", "WALL")}
              />
              <label class="btn n-o-lg-buttons" for="option8">
                Wall
              </label>
            </div>
          </div>
          <div>
            <div className="questionheaders">
              <p className="box-heading ">Pipe Options / Ball Valves</p>
              <p>Select the pipe material and ball valve type.</p>
            </div>
            <div className="contents row  d-flex trio justify-content-center ">
              <div className="col-lg-4    col-md-12 px-4">
                <div
                  class="accordion accordion-flush"
                  id="accordionFlushExample"
                >
                  <div className="accordion-item">
                    <h2 className="accordion-header c-q-pipes">
                      <button
                        className="accordion-button collapsed"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#flush-collapseOne"
                        aria-expanded="false"
                        aria-controls="flush-collapseOne"
                      >
                        {pipeMaterial
                          ? pipeMaterial?.label
                          : "Select Pipe Material"}
                      </button>
                    </h2>
                    {descriptionFormData?.pipeMaterial?.map((item, index) => (
                      <div
                        key={index}
                        id="flush-collapseOne"
                        data-bs-toggle="collapse"
                        data-bs-target="#flush-collapseOne"
                        aria-expanded="false"
                        aria-controls="flush-collapseOne"
                        className={"accordion-collapse c-pointer collapse"}
                        data-bs-parent="#accordionFlushExample"
                      >
                        <div
                          name="pipe-material"
                          className="accordion-body"
                          onClick={() =>
                            handleAccordionClick("pipeMaterial", item)
                          }
                        >
                          {item?.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="col-lg-4   col-md-12 px-4">
                <div
                  class="accordion accordion-flush"
                  id="accordionFlushExample"
                >
                  <div className="accordion-item">
                    <h2 className="accordion-header c-q-pipes">
                      <button
                        className="accordion-button collapsed"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#flush-collapseTwo"
                        aria-expanded="false"
                        aria-controls="flush-collapseTwo"
                      >
                        {ballType ? ballType?.label : "Select Ball Type"}
                      </button>
                    </h2>
                    {descriptionFormData?.ballType?.map((item, index) => (
                      <div
                        key={index}
                        id="flush-collapseTwo"
                        data-bs-toggle="collapse"
                        data-bs-target="#flush-collapseTwo"
                        aria-expanded="false"
                        aria-controls="flush-collapseTwo"
                        className={"accordion-collapse c-pointer collapse"}
                        data-bs-parent="#accordionFlushExample"
                      >
                        <div
                          name="ball-value"
                          className="accordion-body"
                          onClick={() =>
                            handleAccordionClick("ballValue", item)
                          }
                        >
                          {item?.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="col-lg-4   col-md-12 px-4">
                <div
                  class="accordion accordion-flush"
                  id="accordionFlushExample"
                >
                  <div className="accordion-item">
                    <h2 className="accordion-header c-q-pipes">
                      <button
                        className="accordion-button collapsed"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#flush-collapseThree"
                        aria-expanded="false"
                        aria-controls="flush-collapseThree"
                      >
                        {pulsation
                          ? pulsation?.label
                          : "Select Pulsation Dampener"}
                      </button>
                    </h2>
                    {descriptionFormData?.pulsationDampener?.map(
                      (item, index) => (
                        <div
                          key={index}
                          id="flush-collapseThree"
                          data-bs-toggle="collapse"
                          data-bs-target="#flush-collapseThree"
                          aria-expanded="false"
                          aria-controls="flush-collapseThree"
                          className={"accordion-collapse c-pointer collapse"}
                          data-bs-parent="#accordionFlushExample"
                        >
                          <div
                            name="pulsation-dampener"
                            className="accordion-body"
                            onClick={() =>
                              handleAccordionClick("pulsationDampener", item)
                            }
                          >
                            {item?.label}
                          </div>
                        </div>
                      )
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div className="questionheaders">
              <p className="box-heading ">Additional option</p>
              <p>Select any other required skid options below.</p>
            </div>
            <div className="contents row  d-flex trio justify-content-center ">
              <div className="col-lg-6  my2   col-md-12 px-4">
                <Switch
                  onChange={(e) =>
                    handleInputValues(
                      "witness_testing",
                      e.target.checked ? true : false
                    )
                  }
                  checked={inputValue?.witness_testing}
                  size="lg"
                  color="#84151F"
                  label="Witness Testing"
                  description="Does your skid required witness testing?"
                />
              </div>
              <div className="col-lg-6  my-2 ol-md-12 px-4">
                <Switch
                  onChange={(e) =>
                    handleInputValues(
                      "splash_sheild",
                      e.target.checked ? true : false
                    )
                  }
                  checked={inputValue?.splash_sheild}
                  size="lg"
                  color="#84151F"
                  label="Splash Sheild"
                  description="Does your skid required splash sheild?"
                />
              </div>
              <div className="col-lg-6 my-2  col-md-12 px-4">
                <Switch
                  onChange={(e) =>
                    handleInputValues(
                      "manifold",
                      e.target.checked ? true : false
                    )
                  }
                  checked={inputValue?.manifold}
                  size="lg"
                  color="#84151F"
                  label="Manifold"
                  description="Does your skid required manifold?"
                />
              </div>
              <div className="col-lg-6 my-2  col-md-12 px-4">
                <Switch
                  onChange={(e) =>
                    handleInputValues(
                      "seismic_calculation",
                      e.target.checked ? true : false
                    )
                  }
                  checked={inputValue?.seismic_calculation}
                  size="lg"
                  color="#84151F"
                  label="Seismic Calculation"
                  description="Does your skid required seismic calculation?"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="q3-background mt-5" id="customization-box">
          <div>
            <div className="questionheaders position-relative ">
              <p className="box-heading ">Customization</p>
              <p>
                Add or remove special parts or features that are not
                configurable and request a customized quote
              </p>
              <div className="add-btn-box">
                <button
                  className="white-btn d"
                  disabled={customization[customization?.length - 1]?.comment == '' ? true : false}
                  onClick={() => handleAddCustomization()}
                >
                  ADD
                </button>
              </div>
            </div>
            <div className="contents ">
              {customization?.map((value, i) => (
                <div
                  key={i}
                  className="row cstomze justify-content-between mb-3"
                >
                  <div className="col-lg-10  col-md-9 d-flex">
                    <div className="row c-a-cmmts w-100 align-items-center justify-content-between">
                      <div className="col-lg-7 col-md-5 full-width-customization ">
                        <TextInput
                          placeholder="Request here"
                          label="Customization requested"
                          className="w-100"
                          value={customization[i]?.request}
                          onChange={(e) => {
                            const newCustomization = [...customization]; // Make a copy of the array
                            newCustomization[i] = {
                              ...newCustomization[i],
                              request: e.target.value,
                            };
                            setCustomization(newCustomization);
                          }}
                        />
                      </div>
                      <div className="col-lg-4 col-md-5 full-width-customization">
                        <TextInput
                          placeholder="Comment here"
                          label="Additional comments"
                          className="w-100"
                          value={customization[i]?.comment}
                          onChange={(e) => {
                            const newCustomization = [...customization]; // Make a copy of the array
                            newCustomization[i] = {
                              ...newCustomization[i],
                              comment: e.target.value,
                            };
                            setCustomization(newCustomization);
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-1 d-flex  justify-content-end align-items-end col-md-3 rem-ve">
                    <button
                      disabled={customization?.length < 2 ? true : false}
                      onClick={() => handleRemoveCustomization(i)}
                      className="web-btn  px-3"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="d-flex  justify-content-end">
          <button className=" back mx-2" onClick={() => HandleSteps(2)}>
            Back
          </button>
          <button className=" continue mx-2" onClick={handleFormSubmit}>
            Continue
          </button>
        </div>
      </div>
    </>
  );
};
export default Question3;
