import React, { useEffect, useState } from "react";
import "./question2.css";
import "../../Questions/questions.css";
import { Select, Switch } from "@mantine/core";
import { descriptionFormData } from "../../../../../data/data";
import { IconChevronDown } from "@tabler/icons-react";
const Question2 = ({ HandleSteps }) => {
  const [busError, setBusError] = useState("");
  const [clickedText, setClickedText] = useState("Select an Application");
  const [inputValue, setInputValue] = useState({
    materials_of_construction: "",
    materials_of_construction2: "",
    remote_start_stop: false,
    analog_inputs: false,
    analog_outputs: false,
    relay_output: false,
    pulse_control: false,
    graphical_display: false,
    flow_control_monitoring: false,
    spring_loaded_valves: false,
    field_bus: false,
    // seismic_calculation: false,
    leak_detection: false,
    bus_type:"",
  });
  const handleAccordionClick = (select, item) => {
    setClickedText(item?.label);
    setInputValue({ ...inputValue, [select]: item?.value });
  };
  const pumpLiquid = descriptionFormData?.pumpedLiquid.find(
    (material) => material?.value === inputValue?.materials_of_construction
  );
  const pumpLiquid2 = descriptionFormData?.specificPumpedLiquid.find(
    (material) => material?.value === inputValue?.materials_of_construction2
  );
  const materials_of_construction_arr = [
    {
      key: "Aluminum Sulfate 'Alum'",
      value: "alimunum_sulphate",
    },
    {
      key: "Ferric Chloride",
      value: "ferric_chloride",
    },
    {
      key: "Hydrochloric Acid (10%)",
      value: "hydrochloric_acid",
    },
    {
      key: "Peracetic Acid",
      value: "peracetic_acid",
    },
    {
      key: "Sodium Bisulfate",
      value: "sodium_bisulfate",
    },
    {
      key: "Sodium Bisulfite",
      value: "sodium_bisulfite",
    },
    {
      key: "Sodium Hydroxide (50%)",
      value: "sodium_hydroxide",
    },
    {
      key: "Sodium Hypochlorite (12.5%)",
      value: "sodium_hypochlorite",
    },
    {
      key: "Sulfuric Acid (93%)",
      value: "sulfuric_acid",
    },
  ];
  const switcharr = [
    {
      name: "remote_start_stop",
      label: "Remote Start/ Stop",
      description: "Remote Start/ Stop",
    },
    {
      name: "analog_outputs",
      label: "Analog Output",
      description:
        "Pump will output mA signal based on Output, Input, Measured flow or Backpressure.",
    },
    {
      name: "pulse_control",
      label: "Pulse Control",
      description: "Dosed capacity is proportional to external pulse signal.",
    },
    {
      name: "flow_control_monitoring",
      label: "Flow Control / Monitoring",
      description:
        "For off-gassing chemicals and detecting pump or system faults.",
    },
    // {
    //   name: "seismic_calculation",
    //   label: "Seismic Calculation",
    //   description: "Does your system require seismic calculation?",
    // },
    {
      name: "field_bus",
      label: "Field Bus",
      description: "Profibus DP, Modbus RTU or Ethernet.",
    },
  ];
  const switcharr2 = [
    {
      name: "analog_inputs",
      label: "Analog Input",
      description: "Dosed capacity is proportional to external mA input.",
    },
    {
      name: "relay_output",
      label: "Relay Output",
      description:
        "Sends warnings, alarms and pump running status from the pump to a PLC.",
    },
    {
      name: "graphical_display ",
      label: "Graphical Output",
      description: "LCD backlit easy-to-use interface.",
    },
    {
      name: "spring_loaded_valves",
      label: "Spring Loaded",
      description: "Spring loaded check valves, for viscous liquids.",
    },
    {
      name: "leak_detection",
      label: "Leak Detection",
      description: "System requires leak detection.",
    },
  ];
  const handleInputValues = (name, value) => {
    setInputValue({ ...inputValue, [name]: value });
  };
  const handleFormSubmit = () => {
    if (inputValue?.field_bus){
      if(inputValue?.bus_type !== "")
      {
        console.log("nahi hua");
        sessionStorage.setItem("step2", JSON.stringify(inputValue));
        HandleSteps(3);
      }else{
setBusError('Field is required')
      }
    }else{
      sessionStorage.setItem("step2", JSON.stringify(inputValue));
      HandleSteps(3);

    }
  };
  useEffect(()=> {
setBusError('')
  },[inputValue?.field_bus])
  useEffect(() => {
    const step2 = JSON.parse(sessionStorage.getItem("step2"));
    if (step2) {
      setInputValue(step2);
    }
  }, []);
  return (
    <>
      <div className="q2">
        <p className="sub-title">Pump Application</p>
        <div className="questionheaders">
          <p className="box-heading ">Pumped Liquid</p>
          <p>
            This is intended as a general guide for material resistance (at room
            temperature), and does not replace testing of the chemicals and pump
            materials under specific working conditions. The data shown are
            based on information from various sources available, but many
            factors (purity, temperature, abrasive particles, etc.) may affect
            the chemical resistance of a given material.
          </p>
        </div>
        <div className="q-content mt-5  d-flex justify-content-center">
          {" "}
          <div class="accordion accordion-flush" id="accordionFlushExample">
            <div className="accordion-item">
              <h2 className="accordion-header c-q">
                <button
                  className="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseOne"
                  aria-expanded="true"
                  aria-controls="flush-collapseOne"
                >
                  {pumpLiquid ? pumpLiquid?.label : "Select Pumped Liquid"}
                </button>
              </h2>
              {descriptionFormData?.pumpedLiquid?.map((item, index) => (
                <div
                  key={index}
                  id="flush-collapseOne"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseOne"
                  aria-expanded="true"
                  aria-controls="flush-collapseOne"
                  className={"accordion-collapse c-pointer collapse"}
                  data-bs-parent="#accordionFlushExample"
                >
                  <div
                    className="accordion-body"
                    onClick={() =>
                      handleAccordionClick("materials_of_construction", item)
                    }
                  >
                    {item.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        {inputValue?.materials_of_construction === "other" && (
          <div className="q-content mt-1 mb-5 d-flex justify-content-center">
            {" "}
            <div class="accordion accordion-flush" id="accordionFlushExample2">
              <div className="accordion-item">
                <h2 className="accordion-header c-q">
                  <button
                    className="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#flush-collapseTwo"
                    aria-expanded="true"
                    aria-controls="flush-collapseTwo"
                  >
                    {pumpLiquid2
                      ? pumpLiquid2?.label
                      : "Select Custom Material of Construction"}
                  </button>
                </h2>
                {descriptionFormData?.specificPumpedLiquid?.map(
                  (item, index) => (
                    <div
                      key={index}
                      id="flush-collapseTwo"
                      data-bs-toggle="collapse"
                      data-bs-target="#flush-collapseTwo"
                      aria-expanded="true"
                      aria-controls="flush-collapseTwo"
                      className={"accordion-collapse c-pointer collapse"}
                      data-bs-parent="#accordionFlushExample"
                    >
                      <div
                        className="accordion-body"
                        onClick={() =>
                          handleAccordionClick(
                            "materials_of_construction2",
                            item
                          )
                        }
                      >
                        {item.label}
                      </div>
                    </div>
                  )
                )}
              </div>
            </div>
          </div>
        )}
        <div className="w-100">
          <div className="questionheaders">
            <p className="box-heading ">Controls and Functionality</p>
            <p>Select all features that meet your application's need</p>
          </div>
          <div className="q-options d-flex row">
            <div className="q-radios col-lg-6 col-md-12 ">
              {switcharr?.map((item, index) => (
                <div key={index}>
                  <Switch
                    onChange={(e) =>
                      handleInputValues(
                        item.name,
                        e.target.checked ? true : false
                      )
                    }
                    checked={inputValue?.[item?.name]}
                    size="lg"
                    className="mt-5"
                    color="#84151F"
                    label={item.label}
                  />
                  <p className="q-des">{item.description}</p>
                </div>
              ))}
              {inputValue?.field_bus && 
                  <Select
                  
                  placeholder="Select the field bus type"
                  rightSection={<IconChevronDown size="1rem" />}
                  rightSectionWidth={30}
                  value={inputValue?.bus_type}
                  onChange={(value) =>
                    handleInputValues(
                      "bus_type",
                      value
                    )
                  }
                  data={descriptionFormData?.busType}
                />} 
                {busError && <p className='error_text'>{busError}</p>}
            </div>
            <div className="q-radios col-lg-6 col-md-12">
              {switcharr2?.map((item, index) => (
                <div key={index}>
                  <Switch
                    size="lg"
                    onChange={(e) =>
                      handleInputValues(
                        item.name,
                        e.target.checked ? true : false
                      )
                    }
                    checked={inputValue?.[item?.name]}
                    className="mt-5"
                    color="#84151F"
                    label={item.label}
                  />
                  <p className="q-des">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="d-flex justify-content-end">
          <button className=" back mx-2" onClick={() => HandleSteps(1)}>
            Back
          </button>
          <button className=" continue mx-2" onClick={handleFormSubmit}>
            Continue
          </button>
        </div>
      </div>
    </>
  );
};
export default Question2;
