import React from "react";
import { Link } from "react-router-dom";
import "./welcome.css";
const Welcome = () => {
  return (
    <section className="section-welcome">
      <div className="bg-maroon">
        <div className="container">
          <p className="bsleft">Introduction</p>
          <div className="row p-lg-5">
            <div className="bscenter col-md-8 ">
              <p className="welcome-heading">Welcome</p>
              <p className="intro-text">
                At Your Company Name, we're committed to revolutionizing the
                pumping solutions industry by providing cutting-edge
                technologies and unparalleled expertise. With a rich legacy of
                innovation and excellence, we've been at the forefront of
                delivering reliable and efficient pumping solutions to
                businesses worldwide.
              </p>
              <p className="welcome-heading mt-5">Our Mission</p>
              <p className="intro-text">
                Our mission is simple: to empower businesses with reliable and
                efficient pumping solutions that optimize performance and
                enhance productivity. We believe in leveraging advanced
                technology and industry expertise to create customized solutions
                that exceed expectations and deliver tangible results.
              </p>
            </div>
            <div className="bsright col-md-4">
              <h4>We Build Systems</h4>
              <Link
                to="/build-system/dosing-skid-system"
                className="white-btn px-2 mt-2"
              >
                Build New System
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default Welcome;
