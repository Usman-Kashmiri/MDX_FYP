import React, { useEffect, useState } from "react";
import "./mainpage.css";
import Question1 from "./Questions/Question1/Question1";
import Question2 from "./Questions/Question2/Question2";
import Question3 from "./Questions/Question3/Question3";
import Question4 from "./Questions/Question4/Question4";
const MainPage = () => {
  const [handlenext, sethandlenext] = useState(1);

  useEffect(() => {
    const form = localStorage?.getItem("form");
    if (form) {
      sethandlenext(form);
    }
  }, [handlenext]);

  const HandleSteps = (steps = ++handlenext) => {
    localStorage.setItem("form", steps);
    sethandlenext(steps);
  };
  return (
    <>
      <section className="section-mainpage">
        <div className="container">
          <p className="form-heading ">Dosing Skid System Configurator</p>
          {handlenext == 1 ? (
            <Question1 HandleSteps={HandleSteps} />
          ) : handlenext == 2 ? (
            <Question2 HandleSteps={HandleSteps} />
          ) : handlenext == 3 ? (
            <Question3 HandleSteps={HandleSteps} />
          ) : handlenext == 4 ? (
            <Question4 HandleSteps={HandleSteps} />
          ) : (
            ""
          )}
        </div>
      </section>
    </>
  );
};
export default MainPage;