import React, { useEffect, useState } from "react";
import "./question4.css";
import { IconChevronDown } from "@tabler/icons-react";
import { Accordion, Checkbox, Select } from "@mantine/core";
import { descriptionFormData } from "../../../../../data/data";
import { useNavigate } from "react-router-dom";
import { proxy } from "../../../../../redux/actions/proxyActions";
import { useDispatch, useSelector } from "react-redux";
const Question4 = ({ HandleSteps }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [busType, SetBusType] = useState(false);
  const [inputValue, setInputValue] = useState({});
  useEffect(() => {
    const storedData = JSON.parse(sessionStorage.getItem("step1"));
    const storedData2 = JSON.parse(sessionStorage.getItem("step2"));
    const storedData3 = JSON.parse(sessionStorage.getItem("step3"));
    setInputValue({ ...storedData, ...storedData2, ...storedData3 });
  }, []);
  const handleInputValues = (name, value) => {
    setInputValue({ ...inputValue, [name]: value })
  };
  const duplexInlet = descriptionFormData?.outLetConfigg?.find(
    (material) => material?.value === inputValue?.pumpsDuty
  );
  const triplexInlet = descriptionFormData?.outLetConfig?.find(
    (material) => material?.value === inputValue?.pumpsDuty
  );
  const handelnop = (value) => {
    if (value === "SIMPLEX") {
      setInputValue(prevInputValue => ({
        ...prevInputValue,
        pumpsDuty: "Inlet/Outlet"
      }));
    }
    else if (value === "DUPLEX") {
      setInputValue(inputValue => ({
        ...inputValue,
        pumpsDuty: "Duty/Standby"
      }));
    }
    else if (value === "TRIPLEX") {
      setInputValue(inputValue => ({
        ...inputValue,
        pumpsDuty: "Duty/Duty/Standby"
      }));
    }
  }
  const updatesession = () => {
    if (inputValue.flow_capacity) {
      sessionStorage.setItem("step1", JSON.stringify(
        {
          'flow_capacity': inputValue.flow_capacity,
          'flow_pressure': inputValue.flow_pressure
        }));
    }
    if (inputValue.materials_of_construction) {
      sessionStorage.setItem("step2", JSON.stringify(
        {
          'materials_of_construction': inputValue.materials_of_construction,
          'materials_of_construction2': inputValue.materials_of_construction2,
          'remote_start_stop': inputValue.remote_start_stop,
          'analog_inputs': inputValue.analog_inputs,
          'analog_outputs': inputValue.analog_outputs,
          'relay_output': inputValue.relay_output,
          'pulse_control': inputValue.pulse_control,
          'graphical_display': inputValue.graphical_display,
          'flow_control_monitoring': inputValue.flow_control_monitoring,
          'spring_loaded_valves': inputValue.spring_loaded_valves,
          'field_bus': inputValue.field_bus,
          'seismic_calculation': inputValue.seismic_calculation,
          'leak_detection': inputValue.leak_detection,
          'bus_type': inputValue.bus_type
        }));
    }
    if (inputValue.noOfPumps) {
      sessionStorage.setItem("step3", JSON.stringify(
        {
          'noOfPumps': inputValue?.noOfPumps,
          'pumpsDuty': inputValue?.pumpsDuty,
          'pannelType': inputValue?.pannelType,
          'mounting': inputValue?.mounting,
          'pipeMaterial': inputValue?.pipeMaterial,
          'ballValue': inputValue?.ballValue,
          'pulsationDampener': inputValue?.pulsationDampener,
          'witness_testing': inputValue?.witness_testing,
          'splash_sheild': inputValue?.splash_sheild,
          'manifold': inputValue?.manifold,
          'customization': inputValue?.customization,
          // 'customization': inputValue?.customization?.request,
        }));
    }
  }
  // useEffect(() => {
  //   updatesession();
  // }, [inputValue]);
  const handleStartOver = () => {
    sessionStorage.removeItem("step1");
    sessionStorage.removeItem("step2");
    sessionStorage.removeItem("step3");
    HandleSteps(1);
  };
  const handleBuildNew = () => {
    sessionStorage.removeItem("step1");
    sessionStorage.removeItem("step2");
    sessionStorage.removeItem("step3");
    localStorage.removeItem("form");
    navigate("/build-system");
  };
  useEffect(() => {
    {
      console.log("inputValue ", inputValue);
      const payload = {
        inlet_outlet_config: inputValue?.pumpsDuty, // done
        flow_capacity: inputValue?.flow_capacity, // done
        flow_pressure: inputValue?.flow_pressure, // done
        materials_of_construction: inputValue?.materials_of_construction, // done
        custom_materials_of_construction:
        inputValue?.materials_of_construction === "other"?
          inputValue?.custom_materials_of_construction : false, // done
        remote_start_stop: inputValue?.remote_start_stop ? 1 : 0, // done
        analog_inputs: inputValue?.analog_inputs ? 1 : 0, // done
        analog_outputs: inputValue?.analog_outputs ? 1 : 0, // done
        relay_output: inputValue?.relay_output ? 1 : 0, // done
        pulse_control: inputValue?.pulse_control ? 1 : 0 , // done
        graphical_display: inputValue?.graphical_display ? 1 : 0, // done
        flow_control_monitoring: inputValue?.flow_control_monitoring ? 1 : 0, // done
        spring_loaded_valves: inputValue?.spring_loaded_valve ? 1 : 0, // done
        field_bus: inputValue?.field_bus ? 1 : 0, // done
        field_bus_type: inputValue?.bus_type === "Ethernet/IP" ? "E" : inputValue?.bus_type === "Modbus RTU" ? "M" : inputValue?.bus_type === "Modbus TCP" ? "E" : inputValue?.bus_type === "Profibus DP" ? "P" : "M" || "", // missing in form
        system_type:
          inputValue?.noOfPumps ,
          // === 1
          //   ? "SIMPLEX"
          //   : inputValue?.noOfPumps === 2
          //     ? "DUPLEX"
          //     : "TRIPLEX", // done
        panel_type: inputValue?.pannelType, // done
        mounting_type: inputValue?.mounting?.toUpperCase(), // done
        pipe_material: inputValue?.pipeMaterial, // done
        ball_valve_type: inputValue?.ballValue === "Standard" ? "S" : "V", // done
        pulsationDampener: inputValue?.pulsationDampener, // done
        witness_testing: inputValue?.witness_testing ? 1 : 0 || false, // missing in form
        enclosure: inputValue?.enclosure || 1, // missing in form
        manifold: 0, // missing in form
        step: 4, // done
      };
      const extra = {
        chemical_feed_system_application:
          inputValue?.chemical_feed_system_application || "",
        leak_detection: inputValue?.leak_detection || false,
        seismic_calculation: inputValue?.seismic_calculation || false,
      };
      dispatch(proxy({ payload: payload, extra: extra }))
      // dispatch(proxy( payload))
    }
  }, [inputValue]);
  return (
    <>
      <div>
        <div className="d-flex justify-content-end my-3">
          <button className="web-btn px-4 mb-2">Download document</button>
        </div>
        <div className="row justify-content-between align-items-start mx-0">
          <div className="col-lg-5 col-md-12 col-sm-12">
            <div>
              <div className=" questionheaders ps-4 align-items-start">
                <p className="box-heading text-start">Pump Parameters</p>
              </div>
              <div>
                <Accordion>
                  <Accordion.Item value="customization">
                    <Accordion.Control>
                      Flow Capacity - <span>Up to {inputValue.flow_capacity} gph</span>
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Select
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        value={inputValue?.flow_capacity?.toString()}
                        onChange={(value) =>
                          handleInputValues("flow_capacity", value)
                        }
                        data={descriptionFormData?.pumpParameters}
                      />
                    </Accordion.Panel>
                  </Accordion.Item>
                  <Accordion.Item value="flexibility">
                    <Accordion.Control>
                      {" "}
                      Discharge Pressure - <span>Up to {inputValue.flow_pressure} psi</span>
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Select
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        value={inputValue.flow_pressure?.toString()}
                        onChange={(value) =>
                          handleInputValues("flow_pressure", value)
                        }
                        data={descriptionFormData?.dischargePressure}
                      />
                    </Accordion.Panel>
                  </Accordion.Item>
                </Accordion>
              </div>
            </div>
            <div className="mt-4">
              <div className=" questionheaders ps-4 align-items-start">
                <p className="box-heading text-start">Pump Application</p>
              </div>
              <div>
                <Accordion>
                  <Accordion.Item value="customization">
                    <Accordion.Control>Pumped Liquid</Accordion.Control>
                    <Accordion.Panel>
                      <Select
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        onChange={(value) =>
                          handleInputValues("materials_of_construction", value)
                        }
                        value={inputValue?.materials_of_construction}
                        data={descriptionFormData?.pumpedLiquid}
                      />
                      {inputValue?.materials_of_construction === "other" && (
                        <Select
                          className="mt-3"
                          rightSection={<IconChevronDown size="1rem" />}
                          rightSectionWidth={30}
                          onChange={(value) =>
                            handleInputValues(
                              "materials_of_construction2",
                              value
                            )
                          }
                          value={inputValue?.materials_of_construction2}
                          data={descriptionFormData?.specificPumpedLiquid}
                        />
                      )}
                    </Accordion.Panel>
                  </Accordion.Item>
                  <Accordion.Item value="flexibility">
                    <Accordion.Control>
                      Controls and Functionality
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Checkbox
                        className="mb-2"
                        label="Remote Start/Stop"
                        color="#84151f"
                        checked={inputValue?.remote_start_stop}
                        onChange={(value) =>
                          handleInputValues("remote_start_stop", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Analog Input"
                        color="#84151f"
                        checked={inputValue?.analog_inputs}
                        onChange={(value) =>
                          handleInputValues("analog_inputs", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Analog Output"
                        color="#84151f"
                        checked={inputValue?.analog_outputs}
                        onChange={(value) =>
                          handleInputValues("analog_outputs", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Relay Output"
                        color="#84151f"
                        checked={inputValue?.relay_output}
                        onChange={(value) =>
                          handleInputValues("relay_output", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Pulse Control"
                        color="#84151f"
                        checked={inputValue?.pulse_control}
                        onChange={(value) =>
                          handleInputValues("pulse_control", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Graphics Display"
                        color="#84151f"
                        checked={inputValue?.graphical_display}
                        onChange={(value) =>
                          handleInputValues("graphical_display", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Flow Control / Monitoring"
                        color="#84151f"
                        checked={inputValue?.flow_control_monitoring}
                        onChange={(value) =>
                          handleInputValues("flow_control_monitoring", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Spring Loaded Valves"
                        color="#84151f"
                        checked={inputValue?.spring_loaded_valves}
                        onChange={(value) =>
                          handleInputValues("spring_loaded_valves", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Leak Detection"
                        color="#84151f"
                        checked={inputValue?.leak_detection}
                        onChange={(value) =>
                          handleInputValues("leak_detection", value.target.checked)
                        }
                      />
                     
                      <Checkbox
                        className="mb-2"
                        label="Field Bus"
                        color="#84151f"
                        checked={inputValue?.field_bus}
                        onChange={(value) => {
                          handleInputValues("bus_type", "");
                          handleInputValues("field_bus", !inputValue?.field_bus)
                        }}
                      />
                      {inputValue?.field_bus &&
                        <Select
                          rightSection={<IconChevronDown size="1rem" />}
                          rightSectionWidth={30}
                          data={descriptionFormData?.busType}
                          value={inputValue?.bus_type}
                          onChange={(value) =>
                            handleInputValues("bus_type", value)
                          }
                        />}
                    </Accordion.Panel>
                  </Accordion.Item>
                  {/* <Accordion.Item value="field_bus">
                    <Accordion.Control>
                      Field Bus
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Checkbox
                        className="mb-2"
                        label="Spring Loaded Valves"
                        color="#84151f"
                        checked={inputValue?.field_bus}
                        onChange={(value) =>
                          handleInputValues("field_bus", value)
                        }
                      />
                      {inputValue?.field_bus &&
                        <Select
                          rightSection={<IconChevronDown size="1rem" />}
                          rightSectionWidth={30}
                          data={descriptionFormData?.busType}
                          value={inputValue?.bus_type}
                          onChange={(value) =>
                            handleInputValues("bus_type", value)
                          }
                        />}
                    </Accordion.Panel>
                  </Accordion.Item> */}
                </Accordion>
              </div>
            </div>
            <div className="mt-4">
              <div className=" questionheaders ps-4 align-items-start">
                <p className="box-heading text-start">Skid Options</p>
              </div>
              <div>
                <Accordion>
                  <Accordion.Item value="customization">
                    <Accordion.Control>
                      Number of Pumps - <span>{descriptionFormData?.noOfPumps?.find((res) => res.value == inputValue.noOfPumps)?.label}</span>
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Select
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        data={descriptionFormData?.noOfPumps}
                        value={inputValue?.noOfPumps}
                        onChange={(value) => {
                          handleInputValues("noOfPumps", value);
                          handelnop(value);
                        }}
                      />
                    </Accordion.Panel>
                  </Accordion.Item>
                  <Accordion.Item value="flexibility">
                    <Accordion.Control
                      className={
                        inputValue?.noOfPumps == "SIMPLEX"
                          ? "disabel"
                          : ""
                      }>
                      Inlet/Outlet Config - <span>{
    inputValue.noOfPumps === "SIMPLEX"
    ? descriptionFormData?.outLetConfiig?.label
    : inputValue.noOfPumps === "DUPLEX"
        ? duplexInlet?.label
        : inputValue.noOfPumps === "TRIPLEX"
            ? triplexInlet?.label
            : ""
}
</span>
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Select
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        data={
                          inputValue.noOfPumps === "SIMPLEX"
                            ? descriptionFormData?.outLetConfiig
                            : inputValue.noOfPumps === "DUPLEX"
                              ? descriptionFormData?.outLetConfigg
                              : inputValue.noOfPumps === "TRIPLEX"
                                ? descriptionFormData?.outLetConfig
                                : ""
                        }
                        value={inputValue?.pumpsDuty}
                        onChange={(value) =>
                          handleInputValues("pumpsDuty", value)
                        }
                      />
                    </Accordion.Panel>
                  </Accordion.Item>
                  <Accordion.Item value="pannel-type">
                    <Accordion.Control>
                      {" "}
                      Panel Type - <span>{descriptionFormData?.pannelType?.find((res) => res.value == inputValue.pannelType)?.label}</span>
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Select
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        data={descriptionFormData?.pannelType}
                        value={inputValue?.pannelType}
                        onChange={(value) =>
                          handleInputValues("pannelType", value)
                        }
                      />
                    </Accordion.Panel>
                  </Accordion.Item>
                  <Accordion.Item value="mounting">
                    <Accordion.Control>
                      {" "}
                      Mounting - <span>{inputValue?.mounting}</span>
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Select
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        data={descriptionFormData?.mounting}
                        value={inputValue?.mounting}
                        onChange={(value) =>
                          handleInputValues("mounting", value)
                        }
                      />
                    </Accordion.Panel>
                  </Accordion.Item>
                  <Accordion.Item value="pipe-ball">
                    <Accordion.Control>
                      Pipe Options / Ball Valves
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Select
                        label={"Pipe Material"}
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        data={descriptionFormData?.pipeMaterial}
                        value={inputValue?.pipeMaterial}
                        onChange={(value) =>
                          handleInputValues("pipeMaterial", value)
                        }
                      />
                      <Select
                        label={"Ball Valves Type"}
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        data={descriptionFormData?.ballType}
                        value={inputValue?.ballValue}
                        onChange={(value) =>
                          handleInputValues("ballValue", value)
                        }
                      />
                      <Select
                        label={"Pulsation Dampener"}
                        rightSection={<IconChevronDown size="1rem" />}
                        rightSectionWidth={30}
                        data={descriptionFormData?.pulsationDampener}
                        value={inputValue?.pulsationDampener}
                        onChange={(value) =>
                          handleInputValues("pulsationDampener", value)
                        }
                      />
                    </Accordion.Panel>
                  </Accordion.Item>
                  <Accordion.Item value="others">
                    <Accordion.Control>
                      Additional Option
                    </Accordion.Control>
                    <Accordion.Panel>
                      <Checkbox
                        className="mb-2"
                        label="Witness Testing"
                        color="#84151f"
                        checked={inputValue?.witness_testing}
                        onChange={(value) =>
                          handleInputValues("witness_testing", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Splash Sheild"
                        color="#84151f"
                        checked={inputValue?.splash_sheild}
                        onChange={(value) =>
                          handleInputValues("splash_sheild", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Manifold"
                        color="#84151f"
                        checked={inputValue?.manifold}
                        onChange={(value) =>
                          handleInputValues("manifold", value.target.checked)
                        }
                      />
                      <Checkbox
                        className="mb-2"
                        label="Seismic calculation"
                        color="#84151f"
                        checked={inputValue?.seismic_calculation}
                        onChange={(value) =>
                          handleInputValues("seismic_calculation", value.target.checked)
                        }
                      />
                    </Accordion.Panel>
                  </Accordion.Item>
                </Accordion>
              </div>
            </div>
           {inputValue?.customization?.length > 0 &&
    <div>
        <p className="customize-heading">Customization</p>
        <ol>
        {inputValue?.customization?.map((value, i) =>
    value?.request && value?.comment ? (
        <li key={i} className="customization-list">
            {value?.request} | {value?.comment}
        </li>
    ) : null
)}

        </ol>
    </div>
}


            <div className="my-5 d-flex justify-content-start">
              <button
                className="web-btn px-4"
                onClick={() => {
                  HandleSteps(3);
                }}
              >
                ADD CUSTIMZATION
              </button>
            </div>
          </div>
          <div className="col-lg-5 col-md-12 col-sm-12 description-box">
            <p className="desc-heading"></p>
            <p className="desc-text">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s, when an unknown printer took a galley of
              type and scrambled it to make a type specimen book. It has
              survived not only five centuries, but also the leap into
              electronic typesetting, remaining essentially unchanged. It was
              popularised in the 1960s with the release of Letraset sheets
              containing Lorem Ipsum passages, and more recently with desktop
              publishing software like Aldus PageMaker including versions of
              Lorem Ipsum.
            </p>
            <button className="white-btn mb-5" onClick={handleBuildNew}>
              Build New System
            </button>
          </div>
        </div>
      </div>
      <div className="d-flex justify-content-end mt-5">
        <button className=" back mx-2" onClick={() => HandleSteps(3)}>
          Back
        </button>
        <button onClick={handleStartOver} className="continue mx-2">
          Start Over
        </button>
      </div>
    </>
  );
};
export default Question4;
