import { TextInput, Textarea } from "@mantine/core";
import React from "react";
import "./contact.css";

const Contact = () => {
  return (
    <div className="container  my-5">
      <div className="row justify-content-between align-items-start mx-5">
        <div className="col-5 ">
          <p className="contact-heading">Contact Us</p>
          <p className="contact-text mb-4 pe-5">
            Let people know what to reach out about and What to expect after
            contacting you. Don’t forget to choose a storage option for
            submission.
          </p>
          <p className="contact-text mb-1">info@dummycompany.com</p>
          <p className="contact-text mb-1">+1 (555) 123-4567</p>
          <p className="contact-text mb-1">
            1234 Dummy Street, Dummy City, State, Zip Code
          </p>
        </div>
        <div className="col-5">
          <form className="px-5 red-box">
            <TextInput label="Full Name" className="mb-3" />
            <TextInput label="Email" className="mb-3" />
            <Textarea label="Message" className="mb-3" autosize minRows={8} />
            <div className="d-flex justify-content-center">
              <buton className="maroon-btn px-5">Send</buton>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
