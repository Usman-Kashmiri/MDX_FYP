import React, { useEffect, useState } from "react";
import "./question1.css";
import "../../Questions/questions.css";
import { Slider, Text } from "@mantine/core";
import { useNavigate } from "react-router-dom";
import { descriptionFormData } from "../../../../../data/data";
const Question1 = ({ HandleSteps }) => {
  const [clickedText, setClickedText] = useState("Chemical Feed System Application");
  
  const chemical_feed_system_application_arr = [
    { key: "Municipal Water", value: "municipal_water" },
    {
      key: "Municipal Wastewater: General Odor Control",
      value: "m_w:general_dor_Control",
    },
    { key: "Municipal Wastewater: pH Adjustment", value: "m-_w:ph_adjustment" },
    {
      key: "Municipal Wastewater: Residual Disinfectant",
      value: "m_w:residual_disinfectant",
    },
    { key: "General Odor Control", value: "general_odor_control" },
    { key: "Municipal Wastewater: Other", value: "m_w:other" },
    { key: "Food & Beverage", value: "food_&_beverage" },
    { key: "Cooling Tower Treatment", value: "cooling_tower_treatment" },
    { key: "Boiler Water Treatment", value: "boiler_water_treatment" },
    { key: "Mining & Agriculture", value: "mining_&_agriculture" },
    { key: "Pulp & Paper", value: "pulp_&_paper" },
    { key: "Oil & Gas", value: "oil_&_gas" },
    { key: "Other Application", value: "other_application" },
  ];
  const navigate = useNavigate();
  // INITIALIZE ALL INPUTS STATES
  const [inputValue, setInputValue] = useState({
    chemical_feed_system_application: "",
    flow_capacity: 0.5,
    flow_pressure: 60,
  });
  const handleAccordionClick = (text,showtext) => {
    setClickedText(showtext);
    setInputValue({ ...inputValue, chemical_feed_system_application: text });
  };
  // UPDATE INPUT STATES
  const handleInputValues = (name, value) => {
    setInputValue({ ...inputValue, [name]: value });
  };
  // ADD DATA IN SESSION STORAGE AND NAVIGATE TO NEXT FORM
  const handleFormSubmit = () => {
    for (const key in inputValue) {
      if (inputValue[key] === "") {
        return; // Stop form submission if any input field is empty
      }
    }
    sessionStorage.setItem("step1", JSON.stringify(inputValue));
    HandleSteps(2);
  };
  let sea = descriptionFormData?.pumpParameters.filter((res) => res.value);
  useEffect(() => {
    const step1 = JSON.parse(sessionStorage.getItem("step1"));
    console.log(step1);
    if (step1) {
      setInputValue(step1);
    }
  }, []);
  return (
    <div className="q1">
      <div className="questionheaders">
        <p className="box-heading ">
          Select your System Application and your maximum Flow and Pressure
          Requirements
        </p>
        <p>
          Systems are available with 1, 2, or 3 pumps. Duty/duty or duty/standby
          arrangement options are available. Flow capacity selection is per
          pump.
               Discharge pressure is maximum pressure of the entire skid
          system.
        </p>
      </div>
      <div className="q-content d-flex justify-content-center">
        <div className="accordion accordion-flush" id="accordionFlushExample">
          <div className="accordion-item">
            <h2 className="accordion-header c-q">
              <button
                className="accordion-button collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseOne"
                aria-expanded="true"
                aria-controls="flush-collapseOne"
              >
                {clickedText}
              </button>
            </h2>
            {chemical_feed_system_application_arr?.map((item, index) => (
              <div
                key={index}
                id="flush-collapseOne"
                data-bs-toggle="collapse"
                data-bs-target="#flush-collapseOne"
                aria-expanded="true"
                aria-controls="flush-collapseOne"
                className={"accordion-collapse c-pointer collapse"}
                data-bs-parent="#accordionFlushExample"
              >
                <div
                  className="accordion-body"
                  onClick={() => handleAccordionClick(item.value,item.key)}
                >
                  {item.key}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="q-ranges">
        <h4>Flow Capacity</h4>
        <div className="w-75 py-5 mt-5">
          <div>
            <Slider
              className="thmb"
              thumbSize={40}
              defaultValue={60}
              // min={}
              max={315}
              step={
                +inputValue?.flow_capacity > 8 && +inputValue?.flow_capacity < 30 ? 1 :
                +inputValue?.flow_capacity > 30 && +inputValue?.flow_capacity < 52 ? 2 :
                +inputValue?.flow_capacity > 52 ? 10 : 0.5
            }
             min={0.5}
              value={inputValue.flow_capacity}
              color="#84151F"
              onChange={(value) =>
                handleInputValues("flow_capacity", value.toString())
              }
            />
          </div>
          <Text className="float-end" mt="md" size="sm">
            Up to: <b>{inputValue.flow_capacity} GPH</b>
          </Text>
        </div>
        <h4>Discharge Pressure</h4>
        <div className="w-75 py-5">
          <div>
            <Slider
              className="thmb"
              step={10}
              thumbSize={40}
              min={60}
              max={250}
              value={inputValue.flow_pressure}
              color="#84151F"
              onChange={(value) =>
                handleInputValues("flow_pressure", value.toString())
              }
            />
          </div>
          <Text className="float-end" mt="md" size="sm">
            Up to: <b>{inputValue.flow_pressure} PSI</b>
          </Text>
        </div>
      </div>
      <div className="d-flex justify-content-end">
        <button
          className=" back mx-2"
          onClick={() => navigate("/build-system")}
        >
          Back
        </button>
        <button className=" continue mx-2" onClick={handleFormSubmit}>
          Continue
        </button>
      </div>
    </div>
  );
};
export default Question1;
