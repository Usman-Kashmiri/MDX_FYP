import "./App.css";
import { BrowserRouter } from "react-router-dom";
import Router from "./routers/Router";
import "@mantine/core/styles.css";
import { useDispatch } from "react-redux";

import { MantineProvider } from "@mantine/core";
import { useEffect } from "react";
import { proxy } from "./redux/actions/proxyActions";

function App() {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(
      proxy({
        inlet_outlet_config: "inlet_outlet",
        flow_capacity: "7.5",
        flow_pressure: "90",
        materials_of_construction: "peracetic_acid",
        custom_materials_of_construction: "false",
        remote_start_stop: "0",
        analog_inputs: "0",
        analog_outputs: "0",
        relay_output: "0",
        pulse_control: "0",
        graphical_display: "0",
        flow_control_monitoring: "0",
        spring_loaded_valves: "0",
        field_bus: "0",
        field_bus_type: "N",
        system_type: "SIMPLEX",
        panel_type: "NONE",
        mounting_type: "FLOOR",
        pipe_material: "default",
        ball_valve_type: "S",
        pulsation_dampener: "D",
        witness_testing: "0",
        enclosure: "0",
        manifold: "0",
        step: "5",
        "eto_data[0][eto_desc]" : "",
        "eto_data[0][eto_qunatity]" : "",
      })
    );
  }, [dispatch]);
  return (
    <MantineProvider>
      <BrowserRouter>
        <Router />
      </BrowserRouter>
    </MantineProvider>
  );
}
export default App;
