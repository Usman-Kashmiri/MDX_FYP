import React from 'react'
import Welcome from '../components/BuildSystem/Welcome.jsx'

const BuildSystem = () => {
    return (
        <div id="buildsystem">
            <Welcome />
        </div>)
}

export default BuildSystem