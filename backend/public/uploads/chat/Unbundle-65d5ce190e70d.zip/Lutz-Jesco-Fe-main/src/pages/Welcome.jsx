import React from 'react'

const Welcome = () => {
  return (
    <section className=''>
    <div className="container">
                       


    </div>
    </section>
    )
}

export default Welcome