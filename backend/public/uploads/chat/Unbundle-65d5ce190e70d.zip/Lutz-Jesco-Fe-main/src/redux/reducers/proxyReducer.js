import { proxyConstants } from "../constants/proxyConstants";
export const proxyReducer = (
  state = {
    loading: false,
    data: null,
    error: null,
    payload: null,
  },
  action
) => {
  switch (action.type) {
    case proxyConstants.PROXY_REQUEST:
      return { loading: true };
    case proxyConstants.PROXY_SUCCESS:
      return { loading: false, data: { ...state.data, ...action.payload } };
    case proxyConstants.PROXY_FAILURE:
      return { loading: false, error: action.payload };
    case proxyConstants.PROXY_PAYLOAD:
      return { loading: false, payload: action.payload };
    default: // ? defaaaalt case yk...!
      return state;
  }
};
