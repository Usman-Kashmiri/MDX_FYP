import { createStore, combineReducers, applyMiddleware, compose } from "redux";
import { thunk } from "redux-thunk";
// import { composeWithDevTools } from "redux-devtools-extension";
// reducers
import { proxyReducer } from "./reducers/proxyReducer";
const reducer = combineReducers({
  state: proxyReducer,
});
let initialState = {};
const middleware = [thunk];
const store = createStore(
  reducer,
  initialState,
  compose(applyMiddleware(...middleware))
);
export default store;
