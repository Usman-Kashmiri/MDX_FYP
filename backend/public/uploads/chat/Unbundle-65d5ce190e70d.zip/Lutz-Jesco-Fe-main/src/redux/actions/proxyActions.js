import { proxyConstants } from "../constants/proxyConstants";
import custAxios, { formAxios } from "../../configs/axiosConfig";
import {
  successMessage,
  errorMessage,
  warningMessage,
} from "../../services/helpers";

export const proxy = (values) => async (dispatch) => {
  dispatch({
    type: proxyConstants.PROXY_REQUEST,
  });
  try {
    const res = await custAxios.post("/proxy", values);
    console.log(res);
    if (res?.data?.success) {
      dispatch({
        type: proxyConstants.PROXY_SUCCESS,
        payload: res?.data?.data,
      });
      return "success";
    }
  } catch (error) {
    dispatch({
      type: proxyConstants.PROXY_FAILURE,
      payload: error?.response?.data?.message || "Server Error",
    });
    // errorMessage(error?.response?.data?.message );
  }
};
