// Any static data you're going to use will be coded here...
export const descriptionFormData = {
  pumpParameters: [
    {
      value: "0.5",
      label: "up to 0.5 gph",
    },
    {
      value: "1.5",
      label: "up to 1.5 gph",
    },
    {
      value: "2",
      label: "up to 2 gph",
    },
    {
      value: "2.5",
      label: "up to 2.5 gph",
    },
    {
      value: "3",
      label: "up to 3 gph",
    },
    {
      value: "3.5",
      label: "up to 3.5 gph",
    },
    {
      value: "4",
      label: "up to 4 gph",
    },
    {
      value: "4.5",
      label: "up to 4.5 gph",
    },
    {
      value: "5",
      label: "up to 5 gph",
    },
    {
      value: "5.5",
      label: "up to 5.5 gph",
    },
    {
      value: "6",
      label: "up to 6 gph",
    },
    {
      value: "6.5",
      label: "up to 6.5 gph",
    },
    {
      value: "7",
      label: "up to 7 gph",
    },
    {
      value: "7.5",
      label: "up to 7.5 gph",
    },
    {
      value: "8",
      label: "up to 8 gph",
    },
    {
      value: "9",
      label: "up to 9 gph",
    },
    {
      value: "10",
      label: "up to 10 gph",
    },
    {
      value: "11",
      label: "up to 11 gph",
    },
    {
      value: "12",
      label: "up to 12 gph",
    },
    {
      value: "13",
      label: "up to 13 gph",
    },
    {
      value: "14",
      label: "up to 14 gph",
    },
    {
      value: "15",
      label: "up to 15 gph",
    },
    {
      value: "16",
      label: "up to 16 gph",
    },
    {
      value: "17",
      label: "up to 17 gph",
    },
    {
      value: "18",
      label: "up to 18 gph",
    },
    {
      value: "19",
      label: "up to 19 gph",
    },
    {
      value: "20",
      label: "up to 20 gph",
    },
    {
      value: "21",
      label: "up to 21 gph",
    },
    {
      value: "22",
      label: "up to 22 gph",
    },
    {
      value: "23",
      label: "up to 23 gph",
    },
    {
      value: "24",
      label: "up to 24 gph",
    },
    {
      value: "25",
      label: "up to 25 gph",
    },
    {
      value: "26",
      label: "up to 26 gph",
    },
    {
      value: "27",
      label: "up to 27 gph",
    },
    {
      value: "28",
      label: "up to 28 gph",
    },
    {
      value: "29",
      label: "up to 29 gph",
    },
    {
      value: "30",
      label: "up to 30 gph",
    },
    {
      value: "32",
      label: "up to 32 gph",
    },
    {
      value: "34",
      label: "up to 34 gph",
    },
    {
      value: "36",
      label: "up to 36 gph",
    },
    {
      value: "38",
      label: "up to 38 gph",
    },
    {
      value: "40",
      label: "up to 40 gph",
    },
    {
      value: "42",
      label: "up to 42 gph",
    },
    {
      value: "44",
      label: "up to 44 gph",
    },
    {
      value: "48",
      label: "up to 48 gph",
    },
    {
      value: "50",
      label: "up to 50 gph",
    },
    {
      value: "52",
      label: "up to 52 gph",
    },
    {
      value: "60",
      label: "up to 60 gph",
    },
    {
      value: "70",
      label: "up to 70 gph",
    },
    {
      value: "80",
      label: "up to 80 gph",
    },
    {
      value: "90",
      label: "up to 90 gph",
    },
    {
      value: "100",
      label: "up to 100 gph",
    },
    {
      value: "110",
      label: "up to 110 gph",
    },
    {
      value: "120",
      label: "up to 120 gph",
    },
    {
      value: "130",
      label: "up to 130 gph",
    },
    {
      value: "140",
      label: "up to 140 gph",
    },
    {
      value: "150",
      label: "up to 150 gph",
    },
    {
      value: "160",
      label: "up to 160 gph",
    },
    {
      value: "170",
      label: "up to 170 gph",
    },
    {
      value: "180",
      label: "up to 180 gph",
    },
    {
      value: "190",
      label: "up to 190 gph",
    },
    {
      value: "200",
      label: "up to 200 gph",
    },
    {
      value: "210",
      label: "up to 210 gph",
    },
    {
      value: "220",
      label: "up to 220 gph",
    },
    {
      value: "230",
      label: "up to 230 gph",
    },
    {
      value: "240",
      label: "up to 240 gph",
    },
    {
      value: "250",
      label: "up to 250 gph",
    },
    {
      value: "260",
      label: "up to 260 gph",
    },
    {
      value: "270",
      label: "up to 270 gph",
    },
    {
      value: "280",
      label: "up to 280 gph",
    },
    {
      value: "290",
      label: "up to 290 gph",
    },
    {
      value: "300",
      label: "up to 300 gph",
    },{
      value: "310",
      label: "up to 310 gph",
    },{
      value: "315",
      label: "up to 315 gph",
    },
  ],
  dischargePressure: [
    {
      value: "60",
      label: "up to 60 psi",
    },
    {
      value: "65",
      label: "up to 65 psi",
    },
    {
      value: "70",
      label: "up to 70 psi",
    },
    {
      value: "75",
      label: "up to 75 psi",
    },
    {
      value: "80",
      label: "up to 80 psi",
    },
    {
      value: "85",
      label: "up to 85 psi",
    },
    {
      value: "90",
      label: "up to 90 psi",
    },
    {
      value: "95",
      label: "up to 95 psi",
    },
    {
      value: "100",
      label: "up to 100 psi",
    },
    {
      value: "105",
      label: "up to 105 psi",
    },
    {
      value: "110",
      label: "up to 110 psi",
    },
    {
      value: "115",
      label: "up to 115 psi",
    },
    {
      value: "120",
      label: "up to 120 psi",
    },
    {
      value: "125",
      label: "up to 125 psi",
    },
    {
      value: "130",
      label: "up to 130 psi",
    },
    {
      value: "135",
      label: "up to 135 psi",
    },
    {
      value: "140",
      label: "up to 140 psi",
    },
    {
      value: "145",
      label: "up to 145 psi",
    },
    {
      value: "150",
      label: "up to 150 psi",
    },
    {
      value: "155",
      label: "up to 155 psi",
    },
    {
      value: "160",
      label: "up to 160 psi",
    },
    {
      value: "165",
      label: "up to 165 psi",
    },
    {
      value: "170",
      label: "up to 170 psi",
    },
    {
      value: "175",
      label: "up to 175 psi",
    },
    {
      value: "180",
      label: "up to 180 psi",
    },
    {
      value: "185",
      label: "up to 185 psi",
    },
    {
      value: "190",
      label: "up to 190 psi",
    },
    {
      value: "195",
      label: "up to 195 psi",
    },
    {
      value: "200",
      label: "up to 200 psi",
    },
    {
      value: "205",
      label: "up to 205 psi",
    },
    {
      value: "210",
      label: "up to 210 psi",
    },
    {
      value: "215",
      label: "up to 215 psi",
    },
    {
      value: "220",
      label: "up to 220 psi",
    },
    {
      value: "225",
      label: "up to 225 psi",
    },
    {
      value: "230",
      label: "up to 230 psi",
    },
    {
      value: "235",
      label: "up to 235 psi",
    },
    {
      value: "240",
      label: "up to 240 psi",
    },
    {
      value: "245",
      label: "up to 245 psi",
    },
    {
      value: "250",
      label: "up to 250 psi",
    },
  ],
  pumpedLiquid: [
    {
      label: "Aluminum Sulphate 'Alum'",
      value: "alimunum_sulphate",
    },
    {
      label: "Ferric Chloride",
      value: "ferric_chloride",
    },
    {
      label: "Hydrochloric Acid (10%)",
      value: "hydrochloric_acid",
    },
    {
      label: "Peracetic Acid",
      value: "peracetic_acid",
    },
    {
      label: "Sodium Bisulphate",
      value: "sodium_bisulphate",
    },
    {
      label: "Sodium Bisulphite",
      value: "sodium_bisulphite",
    },
    {
      label: "Sodium Hydroxide (50%)",
      value: "sodium_hydroxide",
    },
    {
      label: "Sodium Hypochlorite (12.5%)",
      value: "sodium_hypochlorite",
    },
    {
      label: "Sulphuric Acid (93%)",
      value: "sulphuric_acid",
    },
    {
      label: "Let me select specific material of construction",
      value: "other",
    },
  ],
  specificPumpedLiquid: [
    {
      label: "Dosing Head (PVDF), O-Rings (EPDM), Check Balls (Caramics)",
      value: "Dosing Head (PVDF), O-Rings (EPDM), Check Balls (Caramics)",
    },
    {
      label: "Dosing Head (PVDF), O-Rings (Teflom), Check Balls (Caramics)",
      value: "Dosing Head (PVDF), O-Rings (Teflom), Check Balls (Caramics)",
    },
    {
      label: "Dosing Head (PVDF), O-Rings (Vitor), Check Balls (Caramics)",
      value: "Dosing Head (PVDF), O-Rings (Vitor), Check Balls (Caramics)",
    },
    {
      label: "Dosing Head (PVC), O-Rings (EPDM), Check Balls (Caramics)",
      value: "Dosing Head (PVC), O-Rings (EPDM), Check Balls (Caramics)",
    },
    {
      label: "Dosing Head (PVC), O-Rings (Telfon), Check Balls (Caramics)",
      value: "Dosing Head (PVC), O-Rings (Teflom), Check Balls (Caramics)",
    },
    {
      label: "Dosing Head (PVC), O-Rings (Vitor), Check Balls (Caramics)",
      value: "Dosing Head (PVC), O-Rings (Vitor), Check Balls (Caramics)",
    },
    {
      label:
        "Dosing Head (Stainless), O-Rings (Telfon), Check Balls (Stainless)",
      value:
        "Dosing Head (Stainless), O-Rings (Teflom), Check Balls (Stainless)",
    },
    {
      label:
        "Dosing Head (Stainless), O-Rings (Vitor), Check Balls (Stainless)",
      value:
        "Dosing Head (Stainless), O-Rings (Vitor), Check Balls (Stainless)",
    },
  ],
  busType: [
    { label: "Ethernet/IP", value: "Ethernet/IP" },
    { label: "Modbus RTU", value: "Modbus RTU" },
    { label: "Modbus TCP", value: "Modbus TCP" },
    { label: "Profibus DP", value: "Profibus DP" },
    { label: "Profinet IO", value: "Profinet IO" },
  ],
  noOfPumps: [
    { label: "SIMPLEX (1 PUMP)", value: "SIMPLEX" },
    { label: "DUPLEX (2 PUMPS)", value: "DUPLEX" },
    { label: "TRIPLEX (3 PUMPS)", value: "TRIPLEX" },
    // "SIMPLEX (1 PUMP)",
    // "DUPLEX (2 PUMPS)",
    // "TRIPLEX (3 PUMPS)",
  ],
  outLetConfigg: [{label:"Duty/Standby",value:"duty_standby"}, {label:"Duty/Duty",value:"duty_duty"}],
  outLetConfiig: [{label:"Inlet/Outlet",value:"inlet_outlet"}],
  outLetConfig: [{label:"Duty/Duty/Standby",value:"duty_duty_standby"}, {label:"Duty/Duty/Duty",value:"duty_duty_duty"}],
  pannelType: [
    { label: "None", value: "NONE" },
    { label: "Control Pannel", value: "CONTROLPANEL" },
    { label: "Junction Box", value: "JUNCTIONBOX" },
  ],
  mounting: ["FLOOR", "WALL"],
  pipeMaterial: [
    // "default",
    {
      label: "Default (PVC)",
      value: "default",
    },
    {
      label: "PVC",
      value: "PVC",
    },
    {
      label: "CPVC",
      value: "CPVC",
    },
    {
      label: "PVDF (Kynar)",
      value: "PVDF (Kynar)",
    },
    {
      label: "Stainless Steel",
      value: "stainless_steel",
    },
    // "PVC",
    // "CPVC",
    // "PVDF (Kynar)",
    // "PVDF (Kynar)",
  ],
  ballType: [
    { label: "Standard", value: "Standard" },
    { label: "Vented", value: "Vented" },
    // "Standard",
    // "Vented",
  ],
  pulsationDampener: [
    { label: "Default", value: "D" },
    { label: "Yes", value: "Y" },
    // "D",
    // "Y",
  ],
};
